#ifndef CONSTANTS__
#define CONSTANTS__

#include<stdlib.h>

typedef std::vector<unsigned char> vchType;


#endif


