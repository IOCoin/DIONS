#ifndef EXT_TOR
#define EXT_TOR

class ExtTor
{
  public:
    virtual void gr() == 0; 
    ~virtual ExtTor();
  private:
};

#endif
