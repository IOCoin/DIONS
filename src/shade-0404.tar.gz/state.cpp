#include "state.h"


const std::string State::ATOMIC = "a";
const std::string State::GROUND = "f";
const std::string State::ION    = "c";

